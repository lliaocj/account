package com.example.account.account;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.icu.util.TimeZone;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.Socket;
import java.security.acl.Group;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, CommomDialog.OnCloseListener, CommomDialog.OnUpdateListener,SocketCommon.OnSocketShow, AdapterView.OnItemLongClickListener {

    protected Button mButtonNew;
    protected Button mButtonSet;
    protected Button mButtonSync;
    protected ListView mListView;
    protected long  lastTime;
    public List<UserAccount> AccountInfo = new ArrayList<UserAccount>();
    UserAccountInfo adapter;

    public static String mName;
    public static String mID;
    public static String mTable;

    protected SocketCommon mSocketApi;
    public Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    UserAccount useData = (UserAccount) msg.obj;
                    AccountInfo.add(useData);
                    adapter.notifyDataSetChanged();
                    break;
                case 1:
                    String str = "";
                    String aa[] = (String[]) msg.obj;
                    for(int i = 0; i < aa.length; i++)
                        str = str + aa[i] + '\n';

                    AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                            .setTitle("计算结果")
                            .setMessage(str)
                            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            })


                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            })
                            .create();

                    dialog.show();

                    break;
                case 2:
                {
                    Toast.makeText(MainActivity.this, "与服务器断开连接，重新登录", Toast.LENGTH_SHORT).show();

                    finish();
                }
                break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mActivityInit();
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
        final TextView textView = view.findViewById(R.id.Date);
        final String date = textView.getText().toString();

        if(mName.equals("廖朝军") == false)
            return true;

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("删除");
        builder.setMessage(date);
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mSocketApi.del(date);
                mSocketApi.delBank(date);
                AccountInfo.remove(position);
                adapter.notifyDataSetChanged();
            }
        });
        AlertDialog dialog = builder.create();

        dialog.show();
        return true;


    }

    public class UserAccountInfo extends ArrayAdapter {
        private final int resourceId;
        private List<UserAccount> objects;
        private int color;

        public UserAccountInfo(Context context, int textViewResourceId, List<UserAccount> objects) {
            super(context, textViewResourceId, objects);
            this.objects = objects;
            resourceId = textViewResourceId;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;
            UserAccount mUserInfo = objects.get(position);
            if (convertView == null) {
                view = View.inflate(MainActivity.this, resourceId, null);
            } else {
                view = convertView;
            }

            TextView Date = (TextView) view.findViewById(R.id.Date);
            TextView Name = (TextView) view.findViewById(R.id.Name);
            TextView Money = (TextView) view.findViewById(R.id.Money);
            TextView Note = (TextView) view.findViewById(R.id.Note);

            Date.setText(mUserInfo.GetDate());
            Name.setText(mUserInfo.GetName());
            Money.setText(mUserInfo.GetMoney());
            Note.setText(mUserInfo.GetNote());


            int group = mUserInfo.GetGroup();

            switch (group){
                case 3:
                    color = R.color.color3;
                    break;

                case 5:
                    color = R.color.color5;
                    break;

                case 6:
                    color = R.color.color6;
                    break;
                case 7:
                    color = R.color.color7;
                    break;
            }
            view.setBackgroundColor(getColor(color));

            return view;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mButtonNew: {

                CommomDialog Dialog = new CommomDialog(this, R.style.customHoloLight, this,this);

                Dialog.show();
            }
            break;

            case R.id.mButtonSet: {
                //Intent intent = new Intent(MainActivity.this,UserActivity.class);
                //startActivity(intent);
                mSocketApi.getBank();
            }
            break;

            case R.id.mButtonSync: {
                Toast.makeText(this, "数据正在同步，请稍后....", Toast.LENGTH_SHORT).show();
                AccountInfo.clear();
                mSocketApi.sync();
            }
        }
    }

    @Override
    public void onClick(String date, String name, int group, String money, String note) {
        UserAccount UserData = new UserAccount(date,name, money, note, group);
        AccountInfo.add(UserData);
        adapter.notifyDataSetChanged();
        mSocketApi.push(UserData);
    }

    @Override
    public void onClick(String date, String name,String money, String note)
    {
        mSocketApi.pushBank(date,name, money, note);
    }

    public void mActivityInit() {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyMM");
        Date date = new Date(System.currentTimeMillis());
        mTable = simpleDateFormat.format(date);
        mName = CommonPerSon.getName(this);
        mID   = CommonPerSon.getID(this);


        mButtonNew = (Button) findViewById(R.id.mButtonNew);
        mButtonSet = (Button) findViewById(R.id.mButtonSet);
        mButtonSync = (Button) findViewById(R.id.mButtonSync);

        mListView = (ListView) findViewById(R.id.mListView);
        adapter = new UserAccountInfo(this, R.layout.layout_account, AccountInfo);
        mListView.setAdapter(adapter);
        mListView.setOnItemLongClickListener(this);
        mButtonNew.setOnClickListener(this);
        mButtonSet.setOnClickListener(this);
        mButtonSync.setOnClickListener(this);

        mSocketApi = new SocketCommon(this,handler);
        //mSocketApi.addUser();
        mSocketApi.connect();

        new Thread(){
            @Override
            public void run() {
                try {
                    Thread.sleep(0,500 * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                mSocketApi.sync();
                try {
                    Thread.sleep(0,200 * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                mSocketApi.recvmsg();
            }
        }.start();
    }

    @Override
    public void onClick(int group, String date, String name, final String money, final String note) {

        UserAccount UserData = new UserAccount(date, name, money, note, group);

        Message message = Message.obtain();
        message.what = 0;
        message.obj = UserData;
        handler.sendMessage(message);
    }

    @Override
    protected void onDestroy() {
        mSocketApi.disconnect();
        super.onDestroy();
    }
}
