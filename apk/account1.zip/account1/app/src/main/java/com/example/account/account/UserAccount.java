package com.example.account.account;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by MyPC on 2018/8/15.
 */

public class UserAccount{
    private String Name = MainActivity.mName;
    private String Money = "";
    private String Index = "";
    private String Note = "";
    private int    Group = 0;
    private int    id;

    public UserAccount()
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddHHmmss");
        Date date = new Date(System.currentTimeMillis());
        Index = simpleDateFormat.format(date);

        Name = Name;
        Note = Note + "这是第几个呢 ";
        Money = Money + 0.01;
    }

    public UserAccount(String date, String name, String money, String note, int group)
    {
        Index = date;
        Name = name;
        Money = money;
        Note = note;
        Group = group;
    }

    public UserAccount(String name ,String money, String note, int group)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddHHmmss");
        Date date = new Date(System.currentTimeMillis());
        Index = simpleDateFormat.format(date);
        Name = name;
        Money = money;
        Note = note;
        Group = group;
    }

    public String GetName()
    {
        return Name;
    }

    public String GetMoney()
    {
        return Money;
    }

    public String GetNote()
    {
        return Note;
    }

    public String GetDate(){return Index;}

    public int GetGroup(){return Group;}
}
