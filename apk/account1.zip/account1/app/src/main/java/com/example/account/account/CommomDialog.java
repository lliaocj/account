package com.example.account.account;

import android.app.Activity;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.EditText;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by MyPC on 2018/8/14.
 */

public class CommomDialog extends Dialog implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {
    private CheckBox checkBox1;
    private CheckBox checkBox2;
    private CheckBox checkBox3;
    private RadioGroup radioGroup;

    private String name = MainActivity.mName;
    private Map mMap;
    private int count;

    private EditText moneyETxt;
    private EditText noteETxt;

    private Button submitTxt;
    private Button cancelTxt;

    private String mName;
    private String mMoney;

    private int group = 0x00;

    private Context mContext;
    private OnCloseListener listener;
    private OnUpdateListener listener2;
    private String positiveName;
    private String negativeName;
    private String title;

    public CommomDialog(Context context) {
        super(context);
        this.mContext = context;
    }

    public CommomDialog(Context context, int themeResId) {
        super(context, themeResId);
        this.mContext = context;
    }

    public CommomDialog(Context context, int themeResId, OnCloseListener listener, OnUpdateListener listener2) {
        super(context, themeResId);
        this.mContext = context;
        this.listener = listener;
        this.listener2 = listener2;
        mMap = new HashMap();
    }

    protected CommomDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
        this.mContext = context;
    }

    public CommomDialog setTitle(String title) {
        this.title = title;
        return this;
    }

    public CommomDialog setPositiveButton(String name) {
        this.positiveName = name;
        return this;
    }

    public CommomDialog setNegativeButton(String name) {
        this.negativeName = name;
        return this;
    }

    public void setFocus() {
        submitTxt.requestFocus();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_dialog_commom);
        setCanceledOnTouchOutside(false);
        initView();
    }

    private void setRadioGroup(RadioButton radioButton)
    {
        for(int i = 0; i < 3; i++)
        {
            if(name.equals(radioButton.getText().toString()))
            {
                radioButton.setChecked(true);
            }
        }
    }

    private void initView() {

        checkBox1 = (CheckBox) findViewById(R.id.checkbox1);
        checkBox2 = (CheckBox) findViewById(R.id.checkbox2);
        checkBox3 = (CheckBox) findViewById(R.id.checkbox3);
        radioGroup = (RadioGroup) findViewById(R.id.RadioGroup);
        radioGroup.setOnCheckedChangeListener(this);

        RadioButton radioButton1 = (RadioButton)findViewById(R.id.RadioButton1);
        RadioButton radioButton2 = (RadioButton)findViewById(R.id.RadioButton2);
        RadioButton radioButton3 = (RadioButton)findViewById(R.id.RadioButton3);
        setRadioGroup(radioButton1);
        setRadioGroup(radioButton2);
        setRadioGroup(radioButton3);

        checkBox1.setOnClickListener(this);
        checkBox2.setOnClickListener(this);
        checkBox3.setOnClickListener(this);

        moneyETxt = (EditText) findViewById(R.id.EditTextMoney);
        noteETxt = (EditText) findViewById(R.id.EditTextNote);

        //contentTxt = (TextView)findViewById(R.id.content);
        //titleTxt = (TextView)findViewById(R.id.title);
        submitTxt = (Button) findViewById(R.id.submit);
        submitTxt.setOnClickListener(this);
        cancelTxt = (Button) findViewById(R.id.cancel);
        cancelTxt.setOnClickListener(this);



        //contentTxt.setText(content);
        if (!TextUtils.isEmpty(positiveName)) {
            submitTxt.setText(positiveName);
        }

        if (!TextUtils.isEmpty(negativeName)) {
            cancelTxt.setText(negativeName);
        }

        if (!TextUtils.isEmpty(title)) {
            //titleTxt.setText(title);
        }
        submitTxt.requestFocus();
    }

    public boolean CheckBoxIsCheck(CheckBox checkbox, int num) {
        if (checkbox.isChecked()) {
            Log.e("NOTE", "CheckBoxIsCheck: " + checkbox.getText().toString());
            mMap.put(num, checkbox.getText().toString());
            return true;
        } else {
            mMap.remove(num);
            return false;
        }
    }

    public String To2Decimals(float f)
    {
        DecimalFormat df = new DecimalFormat("#.00");
        return df.format(f);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.checkbox1: {

            }
            break;
            case R.id.checkbox2: {

            }
            break;
            case R.id.checkbox3: {
            }
            break;

            case R.id.cancel:
                this.dismiss();
                break;
            case R.id.submit:

                if (CheckBoxIsCheck(checkBox1, 1) == true) {
                    group = group | (0x01 << 0);
                    count++;
                }

                if (CheckBoxIsCheck(checkBox2, 2) == true) {
                    count++;
                    group = group | (0x01 << 1);
                }

                if (CheckBoxIsCheck(checkBox3, 3) == true) {
                    count++;
                    group = group | (0x01 << 2);
                }

                if(group == 0)
                    group = 7;

                float money = Float.parseFloat(moneyETxt.getText().toString());
                float aver = money / count;
                float mem;

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddHHmmss");
                Date date = new Date(System.currentTimeMillis());
                String index = simpleDateFormat.format(date);

                for (Object key : mMap.keySet()) {

                    mem = 0 - aver;

                    if (name.equals(mMap.get(key))) {

                        mem = money - aver;
                    }
                    //Log.e("NOTE", "name " + mMap.get(key).toString() + "$ = " + mem);

                    if(listener2 != null)
                        listener2.onClick(index,mMap.get(key).toString(),To2Decimals(mem),noteETxt.getText().toString());
                }

                if (listener != null) {

                    listener.onClick(index,name,group, moneyETxt.getText().toString(), noteETxt.getText().toString());
                }

                this.dismiss();//关闭弹窗显示
                break;
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        RadioButton radioButton = (RadioButton)findViewById(checkedId);
        name = radioButton.getText().toString();
    }

    public interface OnCloseListener {
        void onClick(String date,String name,int group, String money, String note);
    }

    public interface OnUpdateListener {
        void onClick(String data,String name,String money, String note);
    }
}
