package com.example.account.account;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.SyncStateContract;

/**
 * Created by MyPC on 2018/8/15.
 */

public class CommonPerSon {
    public static void putString(Context context, String key, String value) {
        SharedPreferences pref = context.getSharedPreferences("Minrray", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getString(Context context, String key) {
        SharedPreferences pref = context.getSharedPreferences("Minrray", Activity.MODE_PRIVATE);
        return pref.getString(key, "");
    }

    public static String getString(Context context, String key, String defaultVaule) {
        SharedPreferences pref = context.getSharedPreferences("Minrray", Activity.MODE_PRIVATE);
        return pref.getString(key, defaultVaule);
    }

    public static String getIp(Context context) {
        return getString(context, "ip", "118.126.88.131");
    }

    public static String getPort(Context context) {
        return getString(context, "port", "1980");
    }

    public static String getName(Context context) {
        return getString(context, "name", "");
    }

    public static String getID(Context context) {
        return getString(context, "id", "101");
    }

    public static void setIp(Context context, String ip) {
        putString(context, "ip", ip);
    }

    public static void setPort(Context context, String port) {
        putString(context, "port", port);
    }

    public static void setName(Context context, String name) {
        putString(context, "name", name);
    }

    public static void setID(Context context, String name) {
        putString(context, "id", name);
    }
}
