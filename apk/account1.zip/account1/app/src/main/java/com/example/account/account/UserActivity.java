package com.example.account.account;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.net.InetSocketAddress;
import java.net.Socket;

public class UserActivity extends AppCompatActivity implements View.OnClickListener, Runnable {

    private final String TAG = "NOTE";
    protected Button mButtonConnect;
    protected EditText mEditTextIP;
    protected EditText mEditTextPort;
    protected Thread TSocketConnect;

    protected Button mButtonReg;
    protected EditText mETxtName;
    protected EditText mETxtID;

    protected String mIP;
    protected int mPort;
    public static Socket mTcpSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user2);
        mActivityInit();
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    String cmd = msg.obj.toString();
                    Toast.makeText(UserActivity.this, cmd, Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void run() {

        Message message = Message.obtain();
        message.what = 0;

        try {
            mTcpSocket = new Socket();
            mTcpSocket.connect(new InetSocketAddress(mIP, mPort), 2000);

            if (mTcpSocket.isConnected()) {

                message.obj = "连接服务器成功，正在获取数据";
                handler.sendMessage(message);
                Intent intent = new Intent(UserActivity.this, MainActivity.class);
                startActivity(intent);
            } else {
                message.obj = "连接服务器超时";
                handler.sendMessage(message);
            }
        } catch (Exception e) {

            message.obj = "连接服务器失败，请重试";
            handler.sendMessage(message);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mButtonConnect: {

                mIP = mEditTextIP.getText().toString();
                mPort = Integer.parseInt(mEditTextPort.getText().toString());

                CommonPerSon.setIp(this, mIP);
                CommonPerSon.setPort(this, mEditTextPort.getText().toString());

                if (mIP.isEmpty() || mPort == 0) {
                    Toast.makeText(UserActivity.this, "请重新输入IP", Toast.LENGTH_SHORT).show();
                    return;
                }

                TSocketConnect = new Thread(this, "TSocketConnect");
                TSocketConnect.start();
            }
            break;

            case R.id.ButtonReg: {
                CommonPerSon.setName(this, mETxtName.getText().toString());
                CommonPerSon.setID(this,mETxtID.getText().toString());
            }
            break;
        }
    }

    protected void mActivityInit() {
        mButtonConnect = (Button) findViewById(R.id.mButtonConnect);
        mEditTextIP = (EditText) findViewById(R.id.editTextIp);
        mEditTextPort = (EditText) findViewById(R.id.editTextPort);
        mETxtName = (EditText) findViewById(R.id.editTextName);
        mETxtID = (EditText) findViewById(R.id.editTextID);

        mETxtName.setText(CommonPerSon.getName(this));
        mETxtID.setText(CommonPerSon.getID(this));
        mButtonReg = (Button) findViewById(R.id.ButtonReg);

        mButtonConnect.setOnClickListener(this);
        mButtonReg.setOnClickListener(this);

        mEditTextIP.setText(CommonPerSon.getIp(this));
        mEditTextPort.setText(CommonPerSon.getPort(this));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
