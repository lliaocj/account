package com.example.account.account;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by MyPC on 2018/8/14.
 */

public class SocketCommon {
    private Socket mSocket;
    private OnSocketShow Lister;
    public Handler handler;
    private byte[] Msg = new byte[2048];
    private int lastPos = 0;

    private String name = MainActivity.mName;
    public static final int NOTE_ADD_USER = 0;
    public static final int NOTE_DEL_USER = 1;
    public static final int NOTE_ADD_BILL = 2;
    public static final int NOTE_SYNC_BILL = 3;
    public static final int NOTE_CONNECT = 4;
    public static final int NOTE_ADD_BANK = 5;
    public static final int NOTE_GET_BANK = 6;
    public static final int NOTE_DEL_BANK = 7;
    public static final int NOTE_DEL_BILL = 8;


    SocketCommon(OnSocketShow mLister, Handler handler) {
        mSocket = UserActivity.mTcpSocket;
        Lister = mLister;
        this.handler = handler;
    }

    public class SendMsg {
        private int offset;
        public byte array[];

        SendMsg(int size) {
            array = new byte[size];
            offset = 0;
        }

        public void WriteByte(Byte b) {
            array[offset] = b;
            offset++;
        }

        public void WriteByte(Byte b, int off) {
            array[off] = b;
        }

        public void WriteInt4(int n) {
            array[3 + offset] = (byte) (n & 0xff);
            array[2 + offset] = (byte) (n >> 8 & 0xff);
            array[1 + offset] = (byte) (n >> 16 & 0xff);
            array[offset] = (byte) (n >> 24 & 0xff);

            offset += 4;
        }

        public void WriteInt4(int n, int off) {
            array[0 + off] = (byte) (n & 0xff);
            array[1 + off] = (byte) (n >> 8 & 0xff);
            array[2 + off] = (byte) (n >> 16 & 0xff);
            array[off + 3] = (byte) (n >> 24 & 0xff);
        }

        public void WriteString(String str) {

            byte[] bytes = str.getBytes();
            for (int i = 0; i < bytes.length; i++) {
                array[offset + i] = bytes[i];
            }

            offset += bytes.length;
        }

        public void WriteString(String str, int length) {

            byte[] bytes = str.getBytes();
            for (int i = 0; i < bytes.length; i++) {
                array[offset + i] = bytes[i];
            }

            offset += length;
        }

        public void Write_l() {
            array[offset] = '|';
            offset++;
        }

        public byte[] GetMsg() {
            return array;
        }

        public int GetOffset() {
            return offset;
        }
    }


    public class RecvMsg {
        private byte array[];
        private int offset;

        RecvMsg(byte[] b) {
            array = b;
            offset = 0;
        }

        public byte ReadByte() {
            byte b = array[offset];
            offset++;
            return b;
        }


        public int ReadInt4() {
            int i = array[offset] & 0xff
                    | (array[offset + 1] & 0xff) << 8
                    | (array[offset + 2] & 0xff) << 16
                    | (array[offset + 3] & 0xff) << 24;
            ;
            offset += 4;

            return i;
        }

        public String ReadString() throws UnsupportedEncodingException {
            byte b[] = new byte[array.length - offset];
            for (int i = 0; i < b.length; i++) {
                b[i] = array[offset + i];
            }

            offset += b.length;

            return new String(b, "UTF-8");
        }

        public String ReadString(int length) {
            //byte b[] = new byte[length];
            int i = 0;

            for (i = 0; i < length; i++) {
                if(array[offset + i] == 0)
                    break;
//                b[i] = array[offset + i];
            }

            byte c[] = new byte[i];
            System.arraycopy(array,offset,c,0,i);

            offset += length;

            String data = new String(c);

            return data;
        }

    }

    public static void intToBytes(int n, byte[] array, int offset) {
        array[3 + offset] = (byte) (n & 0xff);
        array[2 + offset] = (byte) (n >> 8 & 0xff);
        array[1 + offset] = (byte) (n >> 16 & 0xff);
        array[offset] = (byte) (n >> 24 & 0xff);
    }

    public static int bytesToInt(byte b[], int offset) {
        return b[offset + 3] & 0xff
                | (b[offset + 2] & 0xff) << 8
                | (b[offset + 1] & 0xff) << 16
                | (b[offset] & 0xff) << 24;
    }

    public static void StringToBytes(String str, byte[] array, int offset) {
        byte[] bytes = str.getBytes();
        for (int i = 0; i < bytes.length; i++) {
            array[offset + i] = bytes[i];
        }
    }

    public void addUser() {

        SendMsg msg = new SendMsg(40);
        msg.WriteByte((byte) NOTE_ADD_USER);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);
        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void delUser() {
        SendMsg msg = new SendMsg(40);
        msg.WriteByte((byte) NOTE_DEL_USER);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);
        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void connect() {

        SendMsg msg = new SendMsg(256);
        msg.WriteByte((byte) NOTE_CONNECT);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);

        msg.WriteString(MainActivity.mID,6);
        msg.WriteString(MainActivity.mTable + "_" + MainActivity.mID, 12);
        msg.WriteString(name, 12);
        msg.WriteString("18081509", 32);
        msg.WriteInt4(msg.GetOffset() - 17, 1);

        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void sync() {
        SendMsg msg = new SendMsg(256);

        msg.WriteByte((byte) NOTE_SYNC_BILL);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);

        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void push(UserAccount account) {


        SendMsg msg = new SendMsg(512);

        msg.WriteByte((byte) NOTE_ADD_BILL);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);

        msg.Write_l();
        msg.WriteString(account.GetDate());
        msg.Write_l();
        msg.WriteString(account.GetName());
        msg.Write_l();
        msg.WriteString(Integer.toString(account.GetGroup()));
        msg.Write_l();
        msg.WriteString(account.GetMoney());
        msg.Write_l();
        msg.WriteString(account.GetNote());
        msg.Write_l();
        msg.WriteInt4((msg.GetOffset() - 17), 1);
        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void del(String index)
    {
        SendMsg msg = new SendMsg(128);

        msg.WriteByte((byte) NOTE_DEL_BILL);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);
        msg.WriteString(index);
        msg.WriteInt4(msg.GetOffset() - 17,1);
        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void pushBank(String date, String name, String money, String note) {
        SendMsg msg = new SendMsg(512);

        msg.WriteByte((byte) NOTE_ADD_BANK);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);

        msg.Write_l();
        msg.WriteString(date);
        msg.Write_l();
        msg.WriteString(name);
        msg.Write_l();
        msg.WriteString(money);
        msg.Write_l();
        msg.WriteString(note);
        msg.Write_l();
        msg.WriteInt4((msg.GetOffset() - 17), 1);
        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void getBank() {
        SendMsg msg = new SendMsg(17);

        msg.WriteByte((byte) NOTE_GET_BANK);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);

        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public void delBank(String date)
    {
        SendMsg msg = new SendMsg(128);

        msg.WriteByte((byte) NOTE_DEL_BANK);
        msg.WriteInt4(0);
        msg.WriteString(name, 12);

        msg.WriteString(date);
        msg.WriteInt4((msg.GetOffset() - 17), 1);

        sendmsg(msg.GetMsg(), msg.GetOffset());
    }

    public int paraDate(byte[] Msg, int size) throws UnsupportedEncodingException {

        int curr_pos = 0;
        RecvMsg msg = new RecvMsg(Msg);

        while (curr_pos < size) {

            int cmd = msg.ReadByte();
            int length = msg.ReadInt4();
            String name = msg.ReadString(12);

            curr_pos += 17;
//            Log.e("NOTE", "name =  " + name + " cmd = " + cmd + " length" + length + " " + curr_pos + "size" + size);
            if(length > size - curr_pos)
            {
                return size - curr_pos + 17;
            }

            curr_pos += length;
//            Log.e("NOTE", "name =  " + name + " cmd = " + cmd + " length" + length + " " + curr_pos);
            switch (cmd) {
                case NOTE_ADD_BILL: {

                }
                break;

                case NOTE_SYNC_BILL: {
                    String data = msg.ReadString(length);
                    //Log.e("NOTE", "paraDate: --" + data);
                    String aa[] = data.split("\\-");

                    for (int i = 0; i < aa.length; i++) {
                        String bb[] = aa[i].split("\\|");
                        if (bb.length == 6) {
                            //Log.e("NOTE", "paraDate: " + bb.length);
//                            Log.e("NOTE", "paraDate: " + bb[1] + " " + bb[2] + " " + bb[3] + " " + bb[4]);

                            if (Lister != null) {
                                Lister.onClick(Integer.parseInt(bb[3]), bb[1], bb[2], bb[4], bb[5]);
                            }
                        }
                    }

                }
                break;

                case NOTE_GET_BANK: {
                    String data = msg.ReadString();

                    String aa[] = data.split("\\|");
//                for (int i = 0; i < aa.length - 1; i++)
//                    Log.e("NOTE", "paraDate: " + aa[i]);

                    Message message = Message.obtain();
                    message.what = 1;
                    message.obj = aa;
                    handler.sendMessage(message);
                }
                break;

                case NOTE_CONNECT: {

                }
                break;
            }

        }

        return 0;
    }

    public void disconnect() {
        try {
            mSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendmsg(final byte[] b, final int len) {

        new Thread() {
            @Override
            public void run() {
                if (mSocket != null && mSocket.isConnected()) {

                    DataOutputStream writer = null;
                    try {
                        writer = new DataOutputStream(mSocket.getOutputStream());
                        writer.write(b, 0, len);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else
                {
                    Message message = Message.obtain();
                    message.what = 2;
                    handler.sendMessage(message);
                }

            }
        }.start();
    }

    public void recvmsg() {
        new Thread() {
            @Override
            public void run() {
                if (mSocket != null) {
                    try {
                        DataInputStream read = new DataInputStream(mSocket.getInputStream());

                        while (mSocket.isConnected()) {
                            byte recvmsg[] = new byte[1024];
                            int recvlen = read.read(recvmsg);
                            //Log.e("NOTE", "run: " + recvlen);
                            if (recvlen > 0) {

                                System.arraycopy(recvmsg,0,Msg,lastPos,recvlen);

                                lastPos = paraDate(Msg, recvlen + lastPos);

                                //Log.e("NOTE", "run: lastpos" + lastPos);

                                if(lastPos != 0)
                                {
                                    if(lastPos  < recvlen) {
                                        Msg = new byte[2048];
                                        System.arraycopy(recvmsg, recvlen - lastPos, Msg, 0, lastPos);
                                    }
                                    else
                                        System.arraycopy(recvmsg,0, Msg, lastPos - recvlen ,recvlen);
                                }
                                else
                                {
                                    Msg = new byte[2048];
                                }

                            }
                            else
                                Thread.sleep(200,0);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();

    }

    public interface OnSocketShow {
        void onClick(int group, String date, String name, String money, String note);
    }

}
